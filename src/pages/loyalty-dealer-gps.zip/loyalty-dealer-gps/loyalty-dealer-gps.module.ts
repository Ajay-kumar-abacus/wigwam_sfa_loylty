import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoyaltyDealerGpsPage } from './loyalty-dealer-gps';
import { IonicSelectableModule } from 'ionic-selectable';
import { SelectSearchableModule } from 'ionic-select-searchable';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    LoyaltyDealerGpsPage,
  ],
  imports: [
    IonicPageModule.forChild(LoyaltyDealerGpsPage),
    IonicSelectableModule,
    SelectSearchableModule,
    HttpClientModule
  
  ],
})
export class LoyaltyDealerGpsPageModule {}

import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'page-loyalty-dealer-gps',
  templateUrl: 'loyalty-dealer-gps.html',
})
export class LoyaltyDealerGpsPage implements OnInit {
  messages: any[] = [];
  userMessage: string = '';
  apiKey: string = 'AIzaSyDQPMtv9-ERW3F2z0cBL3f-Ow5tCiKYf_k'; // Replace with your actual Gemini API key
  predefinedQuestions: string[] = [];
  isLoading: boolean = false; // Loading state for typing indicator

  predefinedAnswers: { [key: string]: string } = {
    'How do I reset my password?': 'To reset your password, go to the login page, click on “Forgot Password,” and follow the instructions.',
    'How do I update my profile?': 'You can update your profile from the settings page under the “Edit Profile” section.',
    'How do I contact support?': 'You can contact support through the “Help” section in the app or email support@example.com.',
    'What are your working hours?': 'Our support team is available from 9 AM to 6 PM, Monday to Friday.',
    'How can I track my order?': 'You can track your order from the “Orders” section in your account dashboard.',
  };

  constructor(public navCtrl: NavController, private http: HttpClient) {}

  ngOnInit() {
    this.predefinedQuestions = Object.keys(this.predefinedAnswers);
  }

  sendMessage(userMessage: string) {
    if (!userMessage.trim()) return;

    const userText = userMessage;
    this.messages.push({ text: userText, sender: 'user' });
    this.userMessage = '';

    // Set loading state to true to show the typing indicator
    this.isLoading = true;

    // Try to find a similar predefined answer
    const closestQuestion = this.findClosestMatch(userText);

    if (closestQuestion) {
      this.messages.push({ text: this.predefinedAnswers[closestQuestion], sender: 'bot' });
      this.isLoading = false; // Hide typing indicator after response
      return;
    }

    // If no predefined answer, use Gemini API
    const requestBody = {
      contents: [{ role: 'user', parts: [{ text: userText }] }]
    };

    this.http.post(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${this.apiKey}`, requestBody, {
      headers: { 'Content-Type': 'application/json' }
    }).subscribe((res: any) => {
      if (res && res.candidates && res.candidates.length > 0) {
        const botReply = res.candidates[0].content.parts[0].text;
        this.messages.push({ text: botReply, sender: 'bot' });
      } else {
        this.messages.push({ text: 'Error: No response from Gemini AI.', sender: 'bot' });
      }
      this.isLoading = false; // Hide typing indicator after response
    }, err => {
      console.error(err);
      this.messages.push({ text: 'Error: Unable to fetch response.', sender: 'bot' });
      this.isLoading = false; // Hide typing indicator on error
    });
  }

  findClosestMatch(userMessage: string): string | null {
    let bestMatch = null;
    let highestScore = 0;

    this.predefinedQuestions.forEach(question => {
      const score = this.calculateSimilarity(userMessage, question);
      if (score > highestScore) {
        highestScore = score;
        bestMatch = question;
      }
    });

    return bestMatch;
  }

  calculateSimilarity(str1: string, str2: string): number {
    const words1 = str1.toLowerCase().split(' ');
    const words2 = str2.toLowerCase().split(' ');
    const commonWords = words1.filter(word => words2.includes(word));
    return commonWords.length / Math.max(words1.length, words2.length);
  }
}

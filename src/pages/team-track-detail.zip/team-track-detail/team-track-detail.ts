import { Component, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';
import { MyserviceProvider } from '../../providers/myservice/myservice';
import { Storage } from '@ionic/storage';
import { DbserviceProvider } from '../../providers/dbservice/dbservice';
import { CheckinNewPage } from '../checkin-new/checkin-new';

declare const L: any;

interface UserLocation {
  lat: number;
  lng: number;
  gps: string;
  username: string;
  avatar?: string;
  role?: string;
  timestamp?: string;
  status?: string;
  
}

@IonicPage()
@Component({
  selector: 'page-team-track-detail',
  templateUrl: 'team-track-detail.html',
})
export class TeamTrackDetailPage {
  @ViewChild('map') mapElement: ElementRef;
  @ViewChild('searchInput') searchInput: ElementRef;
  
  TabType: string = 'Live';
  myMap: any;
  markers: any[] = [];
  routeControl: any;
  searchResults: any[] = [];
  isSearching: boolean = false;
  isNavigating: boolean = false; // Track if navigation is active
  watchId: number = null; // Store the ID for geolocation watch
  currentPositionMarker: any = null;
  
  isBottomSheetOpen: boolean = false;
  selectedUser: UserLocation = null;
  
  // Current location
  latest_location: UserLocation = {
    lat: 37.7749,
    lng: -122.4194,
    gps: "123 Market Street, San Francisco, CA 94105",
    username: "Admin"
  };
  userLocations: any;
  userDetail: any;
  
  constructor(
    public navCtrl: NavController,
    public service: MyserviceProvider,
    public storage: Storage, 
    public db: DbserviceProvider,
    private renderer: Renderer2
  ) {
    this.getteamDetail();
  }

  ionViewWillEnter() {
    setTimeout(() => {
      this.configureMap();
    }, 1000);
  }

  getteamDetail() {
    // this.service.presentLoading();

    this.service.addData({}, 'AppAttendence/teamMemberMapData').then((result) => {
      if (result['statusCode'] == 200) {
        // this.userLocations = result['result'];
         this.userLocations =[];
        this.service.dismissLoading();
      } else {
        this.service.errorToast(result['statusMsg']);
        this.service.dismissLoading();
      }
    }, err => {
      this.service.Error_msg(err);
      this.service.dismiss();
    });
  }

  configureMap() {
    if (this.myMap) {
      this.myMap.off();
      this.myMap.remove();
      this.markers = [];
    }
    
    // Initialize the map centered on the latest location
    this.myMap = L.map('map', {
      center: [this.latest_location.lat, this.latest_location.lng],
      zoomControl: false,
      zoom: 13
    });
    
    // Add Google Streets layer
    const googleStreets = L.tileLayer('https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
      maxZoom: 20,
      subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
      attribution: '&copy; Google Maps'
    });
    
    googleStreets.addTo(this.myMap);

    // Setup routing control
    this.setupRouting();
    
    // Add markers for each user location
    this.addUserMarkers();
    
    // Set map bounds to include all markers
    this.fitMapToMarkers();
  }

  setupRouting() {
    // Add Leaflet Routing Machine control
    if (L.Routing) {
      this.routeControl = L.Routing.control({
        waypoints: [],
        routeWhileDragging: true,
        showAlternatives: true,
        fitSelectedRoutes: true,
        show: false, // Hide the itinerary by default
        lineOptions: {
          styles: [
            { color: '#3388ff', opacity: 0.8, weight: 6 },
            { color: '#ffffff', opacity: 0.3, weight: 4 }
          ]
        },
        router: L.Routing.osrmv1({
          serviceUrl: 'https://router.project-osrm.org/route/v1',
          profile: 'driving'
        })
      }).addTo(this.myMap);
    }
  }

  searchLocation() {
    const query = this.searchInput.nativeElement.value;
    if (!query) return;

    this.isSearching = true;
    this.searchResults = [];

    // Use Nominatim API for geocoding (for demo - in production consider using a paid service)
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
      .then(response => response.json())
      .then(data => {
        this.searchResults = data.slice(0, 5); // Limit to top 5 results
        this.isSearching = false;
      })
      .catch(error => {
        console.error('Error searching location:', error);
        this.isSearching = false;
        this.service.errorToast('Error searching location. Please try again.');
      });
  }

  selectSearchResult(result) {
    // Close search results
    this.searchResults = [];
    this.searchInput.nativeElement.value = result.display_name;
    
    // Add marker for the selected location
    const searchMarker = L.marker([result.lat, result.lon], {
      icon: L.divIcon({
        className: 'search-marker',
        html: `<div class="marker-pin"></div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 40]
      })
    }).addTo(this.myMap);
    
    this.markers.push(searchMarker);
    
    // Center map on the search result
    this.myMap.setView([result.lat, result.lon], 15);
    
    // Show popup with location name
    searchMarker.bindPopup(result.display_name).openPopup();

     // Define the destination using the selected search result's coordinates
     const destination = L.latLng(result.lat, result.lon);

     // Calculate and display the route from current location to the destination
     this.calculateRoute(destination);

     this.startNavigation(destination);
  }

  calculateRoute(destination) {
    // Get current location (using the first user location for demo purposes)
    let startPoint;
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          startPoint = L.latLng(position.coords.latitude, position.coords.longitude);
          this.showRoute(startPoint, destination);
        },
        (error) => {
          console.error('Error getting current location:', error);
          // Fallback to first user location
          if (this.userLocations && this.userLocations.length > 0) {
            startPoint = L.latLng(this.userLocations[0].latestLat, this.userLocations[0].latestLng);
            this.showRoute(startPoint, destination);
          } else {
            this.service.errorToast('Could not determine your current location.');
          }
        }
      );
    } else {
      // Fallback to first user location
      if (this.userLocations && this.userLocations.length > 0) {
        startPoint = L.latLng(this.userLocations[0].latestLat, this.userLocations[0].latestLng);
        this.showRoute(startPoint, destination);
      } else {
        this.service.errorToast('Geolocation is not supported by this browser.');
      }
    }
  }

  showRoute(start, end) {
    if (this.routeControl) {
      // Clear any existing routes
      this.routeControl.setWaypoints([]);
      
      // Set new route waypoints
      this.routeControl.setWaypoints([
        start,
        end
      ]);
    } else {
      this.service.errorToast('Routing functionality is not available.');
    }
  }

  addUserMarkers() {
    // Add markers for all user locations
    this.userLocations.forEach(location => {
      // Get first letter of username for the marker label
      const firstLetter = location.name.charAt(0).toUpperCase();
      
      // Create custom marker with the first letter
      const customIcon = L.divIcon({
        className: 'custom-user-marker',
        html: `<div class="marker-circle">${firstLetter}</div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
      });
      
      // Add marker to map with custom icon
      const marker = L.marker([location.latestLat, location.latestLng], {
        icon: customIcon
      }).addTo(this.myMap);
      
      // When marker is clicked, open bottom sheet with user details
      marker.on('click', () => {
        this.openBottomSheet(location);
      });
      
      this.markers.push(marker);
    });
  }

  fitMapToMarkers() {
    if (this.markers.length > 0) {
      const group = L.featureGroup(this.markers);
      this.myMap.fitBounds(group.getBounds(), { padding: [50, 50] });
    }
  }

  getuserDetail(user) {
    // this.service.presentLoading();

    this.service.addData({'user_id':user.id}, 'AppAttendence/teamMemberMapDataDetail').then((result) => {
      if (result['statusCode'] == 200) {
        this.selectedUser = result['result'];
        this.isBottomSheetOpen = true;
        this.service.dismissLoading();
      } else {
        this.service.errorToast(result['statusMsg']);
        this.service.dismissLoading();
      }
    }, err => {
      this.service.Error_msg(err);
      this.service.dismiss();
    });
  }

  openBottomSheet(user: UserLocation) {
    this.getuserDetail(user);
  }

  closeBottomSheet() {
    this.isBottomSheetOpen = false;
  }

  // Calculate how long ago the timestamp was
  getTimeAgo(timestamp: string): string {
    if (!timestamp) return 'N/A';
    
    const now = new Date();
    const time = new Date(timestamp);
    const diff = Math.floor((now.getTime() - time.getTime()) / 60000); // minutes
    
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff} minutes ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return `${Math.floor(diff / 1440)} days ago`;
  }

  // Navigate to user detail page
  viewUserDetail(user) {
    this.navCtrl.push(CheckinNewPage,{'userIdTrack':user.id});
  }

  // Call the selected user
  callUser(user: UserLocation) {
    console.log('Calling:', user.username);
    // Implement call functionality
  }

  // Send message to selected user
  messageUser(user: UserLocation) {
    console.log('Messaging:', user.username);
    // Implement message functionality
  }

  // Get directions to a user's location
  getDirections(user) {
    const destination = L.latLng(user.lat, user.lng);
    this.calculateRoute(destination);
    this.closeBottomSheet();
  }

  clearRoute() {
    if (this.routeControl) {
      this.routeControl.setWaypoints([]);
    }
  }

  goBack() {
    this.navCtrl.pop();
  }


   // --- Navigation Functions ---

   startNavigation(destination) {
    if (this.isNavigating) {
      this.stopNavigation(); // Stop previous navigation if any
    }

    if (navigator.geolocation) {
      this.service.presentLoading('Starting Navigation...');
      navigator.geolocation.getCurrentPosition(
        (initialPosition) => {
          this.service.dismissLoading();
          const startPoint = L.latLng(initialPosition.coords.latitude, initialPosition.coords.longitude);

          // Show the initial route
          this.showRoute(startPoint, destination);

          // Create or update the current position marker
          this.updateCurrentPositionMarker(startPoint);
          this.myMap.setView(startPoint, 16); // Zoom in closer for navigation

          // Start watching for position changes
          this.isNavigating = true;
          this.watchId = navigator.geolocation.watchPosition(
            (position) => {
              const currentLatLng = L.latLng(position.coords.latitude, position.coords.longitude);
              this.updateCurrentPositionMarker(currentLatLng);
              this.myMap.panTo(currentLatLng); // Smoothly pan the map

              // Optional: Update route if needed (more complex)
              // this.routeControl.spliceWaypoints(0, 1, currentLatLng);

            },
            (error) => {
              console.error('Error watching position:', error);
              this.service.errorToast(`Location tracking error: ${error.message}`);
              this.stopNavigation(); // Stop if watching fails
            },
            { // Options for watchPosition
              enableHighAccuracy: true,
              timeout: 10000, // Timeout after 10 seconds
              maximumAge: 0 // Don't use cached position
            }
          );
        },
        (error) => {
          this.service.dismissLoading();
          console.error('Error getting initial location:', error);
          this.service.errorToast(`Could not get initial location: ${error.message}`);
          // Optionally fallback to the old calculateRoute logic without watching
          // this.calculateRoute(destination);
        },
        { enableHighAccuracy: true } // Options for getCurrentPosition
      );
    } else {
      this.service.errorToast('Geolocation is not supported by this browser.');
    }
  }

  stopNavigation() {
    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    this.isNavigating = false;
    this.removeCurrentPositionMarker();
    this.clearRoute(); // Optionally clear the route line
    this.service.successToast('Navigation stopped.');
    // Maybe zoom out again
    // this.fitMapToMarkers();
  }

  updateCurrentPositionMarker(latLng) {
    if (!this.currentPositionMarker) {
      // Create a simple blue circle marker for current position
      this.currentPositionMarker = L.circleMarker(latLng, {
        radius: 8,
        fillColor: "#3388ff",
        color: "#fff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8
      }).addTo(this.myMap);
      this.currentPositionMarker.bindPopup("Your Location").openPopup();
    } else {
      this.currentPositionMarker.setLatLng(latLng);
    }
    // Keep the marker popup open if it exists
    if (this.currentPositionMarker.isPopupOpen && !this.currentPositionMarker.isPopupOpen()) {
        this.currentPositionMarker.openPopup();
    }
  }

  removeCurrentPositionMarker() {
    if (this.currentPositionMarker) {
      this.myMap.removeLayer(this.currentPositionMarker);
      this.currentPositionMarker = null;
    }
  }

  // --- Lifecycle Hook for Cleanup ---
  ionViewWillLeave() {
    this.stopNavigation(); // Stop tracking when leaving the page
  }

}